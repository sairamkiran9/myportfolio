import { motion } from 'framer-motion';
import ExperienceCard from './ExperienceCard';

const experiences = [
  {
    title: "Senior Frontend Developer",
    company: "Tech Corp",
    period: "2021 - Present",
    description: [
      "Led development of multiple React-based web applications",
      "Implemented CI/CD pipelines reducing deployment time by 50%",
      "Mentored junior developers and conducted code reviews"
    ]
  },
  {
    title: "Full Stack Developer",
    company: "Digital Solutions Inc",
    period: "2019 - 2021",
    description: [
      "Developed and maintained multiple client projects",
      "Implemented RESTful APIs using Node.js and Express",
      "Optimized database queries improving performance by 40%"
    ]
  },
  {
    title: "Junior Developer",
    company: "StartUp Co",
    period: "2017 - 2019",
    description: [
      "Built responsive web applications using React",
      "Collaborated with designers to implement UI/UX improvements",
      "Participated in daily stand-ups and sprint planning"
    ]
  }
];

export default function Experience() {
  return (
    <section className="py-20 bg-gray-900">
      <div className="max-w-6xl mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl font-bold text-center text-white mb-16"
        >
          Work Experience
        </motion.h2>

        <div className="relative space-y-8 before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-gray-700 before:to-transparent">
          {experiences.map((experience, index) => (
            <ExperienceCard key={index} {...experience} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}