import { motion } from 'framer-motion';
import { Code2, Palette, Terminal } from 'lucide-react';

export default function About() {
  const skills = [
    {
      icon: <Code2 className="w-6 h-6" />,
      title: "Frontend Development",
      description: "Expert in React, TypeScript, and modern CSS frameworks"
    },
    {
      icon: <Terminal className="w-6 h-6" />,
      title: "Backend Development",
      description: "Proficient in Node.js, Python, and database management"
    },
    {
      icon: <Palette className="w-6 h-6" />,
      title: "UI/UX Design",
      description: "Creating beautiful and intuitive user interfaces"
    }
  ];

  return (
    <section className="py-20 bg-gray-800">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-white mb-4">About Me</h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            I'm a passionate developer who loves creating beautiful and functional web applications.
            With years of experience in both frontend and backend development, I bring ideas to life.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {skills.map((skill, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="bg-gray-700 p-6 rounded-lg hover:bg-gray-600 transition-colors"
            >
              <motion.div
                whileHover={{ scale: 1.1 }}
                className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mb-4 mx-auto text-white"
              >
                {skill.icon}
              </motion.div>
              <h3 className="text-xl font-bold text-white mb-2 text-center">{skill.title}</h3>
              <p className="text-gray-400 text-center">{skill.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}